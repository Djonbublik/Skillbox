public class Main {
    public static void main(String[] args) {
        Arithmetic arithmetic = new Arithmetic (8,9);

        Arithmetic.mnozhitelNumber();
        Arithmetic.slozhenieNumber();
        Arithmetic.bolshieNumber();
        Arithmetic.menshieNumber();






    }
}

